import Foundation


struct TopLevelObject: Decodable { // JSON
    let count: Int
    let results: [People]
}

struct People: Decodable { // Objects found in the entries array
    let name: String
    let height: String
    let mass: String
    let hair_color: String
    let skin_color: String
    let eye_color: String
    let birth_year: String
    let films: [URL]
}

struct Film: Decodable {
    let title: String
    let opening_crawl: String
    let release_date: String
}


class SWAPIController {
    
    // https://swapi.dev/api/people/
    static let baseURL = URL(string: "https://swapi.dev/api/")
    
    
    static func fetchAllPeople(completion: @escaping (TopLevelObject?) -> Void) {
        
        guard let baseURL = baseURL else { return }
        
        
        let peopleURL = baseURL.appendingPathComponent("people")
        let componets = URLComponents(url: peopleURL, resolvingAgainstBaseURL: true)
        guard let finalURL = componets?.url else { return completion(nil) }
        print(finalURL)
    
        URLSession.shared.dataTask(with: finalURL) { (data, _, error) in
            if let error = error {
                print("======ERROR======")
                print("Function: \(#function)")
                print("Error: \(error)")
                print("Description: \(error.localizedDescription)")
                print("======ERROR======")
                return completion(nil)
            }

            guard let data = data else { return completion(nil)}
            do {
                let people = try JSONDecoder().decode(TopLevelObject.self, from: data)
                completion(people)
            } catch {
                print("======ERROR======")
                print("Function: \(#function)")
                print("Error: \(error)")
                print("Description: \(error.localizedDescription)")
                print("======ERROR======")
                return completion(nil)
            }
        }.resume()
    } // end of fetchAllCategories Function
    
    
    
    static func fetchOnePerson(id: Int, completion: @escaping (People?) -> Void) {
        
        guard let baseURL = baseURL else { return }
        print(baseURL)
        
        let peopleURL = baseURL.appendingPathComponent("people/\(id)")
        print(peopleURL)
        
        let componets = URLComponents(url: peopleURL, resolvingAgainstBaseURL: true)
        print(componets)
        
        guard let finalURL = componets?.url else { return completion(nil) }
        print(finalURL)
    
        URLSession.shared.dataTask(with: finalURL) { (data, _, error) in
            if let error = error {
                print("======ERROR======")
                print("Function: \(#function)")
                print("Error: \(error)")
                print("Description: \(error.localizedDescription)")
                print("======ERROR======")
                return completion(nil)
            }

            guard let data = data else { return completion(nil)}

            do {
                let person = try JSONDecoder().decode(People.self, from: data)
                completion(person)
            } catch {
                print("======ERROR======")
                print("Function: \(#function)")
                print("Error: \(error)")
                print("Description: \(error.localizedDescription)")
                print("======ERROR======")
                return completion(nil)
            }
        }.resume()
    } // end of fetchAllCategories Function
    
    
    static func fetchFilms(filmURL: URL, completion: @escaping (Film?) -> Void) {
        
        URLSession.shared.dataTask(with: filmURL) { (data, _, error) in
            if let error = error {
                print("======ERROR======")
                print("Function: \(#function)")
                print("Error: \(error)")
                print("Description: \(error.localizedDescription)")
                print("======ERROR======")
                return completion(nil)
            }

            guard let data = data else { return completion(nil)}

            do {
                let film = try JSONDecoder().decode(Film.self, from: data)
                completion(film)
            } catch {
                print("======ERROR======")
                print("Function: \(#function)")
                print("Error: \(error)")
                print("Description: \(error.localizedDescription)")
                print("======ERROR======")
                return completion(nil)
            }
        }.resume()
    } // end of fetchAllCategories Function
    
    

} // end of Class
    
//SWAPIController.fetchAllPeople { (TopLevelData) in
//    guard let TopLevelData = TopLevelData else { return }
//    print(TopLevelData.count)
//    for person in TopLevelData.results {
//        print(person)
//    }
//}

SWAPIController.fetchOnePerson(id: 4) { (Person) in
    guard let person = Person else { return }
    print("\nName of Character: \(person.name)")
    print("Height: \(person.height)")
    print("Mass: \(person.mass)")
    print("Hair Color: \(person.hair_color)\n")
    
    
    for film in person.films {
        SWAPIController.fetchFilms(filmURL: film) { (Film) in
            guard let film = Film else { return }
            print(film.title)
        }
    }
}
